# Sales Page Framework Guide

This reference provides detailed guidance for each section of a high-converting sales page.

---

## Section 1: Headline Stack

### Primary Headline
- Lead with the biggest, most specific promise
- Include a number if possible (time, money, results)
- Make it about the reader, not the product

**Formula options:**
- "How to [achieve result] in [timeframe] without [common obstacle]"
- "The [adjective] way to [achieve result] even if [objection]"
- "Why [common approach] is [problem] (and what to do instead)"

### Subheadline
- Expand on the mechanism
- Add credibility or proof element
- Bridge to the opening

### Pre-headline
- Qualify the reader
- Create curiosity
- Set context

---

## Section 2: Opening Hook

### Pattern Interrupt
Start with something unexpected:
- A surprising fact
- A contrarian statement
- A story opening
- A direct challenge

### Problem Agitation
- Describe the pain vividly
- Show you understand their frustration
- Build emotional resonance

### Solution Introduction
- Position the product as the answer
- Hint at the mechanism
- Create curiosity about what's coming

---

## Section 3: External Proof Layer

### Types of Proof
1. **Quantified results** — "Generated $X in Y days"
2. **Timeline proof** — "First sale within 24 hours"
3. **Social proof** — Testimonials with specific outcomes
4. **Expert validation** — Endorsements or credentials
5. **Usage proof** — "X people have already..."

### Testimonial Structure
- Before state (the struggle)
- The discovery (finding the solution)
- After state (the result)
- Specific numbers or outcomes

---

## Section 4: Specific Outcome Anchoring

### Transform Vague Benefits

| Vague | Specific |
|-------|----------|
| "Save time" | "Launch in 37 minutes" |
| "Make money" | "First $1,000 month" |
| "Get fit" | "Lose 10 lbs in 30 days" |
| "Learn faster" | "Master Spanish in 90 days" |

### Time-Bound Outcomes
- "Within 7 days..."
- "By the end of week 2..."
- "Within 30 days..."

---

## Section 5: The Mechanism

### Step-by-Step Breakdown
Present the process as engineered, not magical:

1. **Step 1** — What happens, why it matters
2. **Step 2** — What happens, why it matters
3. **Step 3** — What happens, why it matters

### Why It Works
- Explain the underlying principle
- Reference proven methods or research
- Show why other approaches fail

---

## Section 6: Objection Domination

### Handling Structure
For each objection:
1. **Name it** — "You might be thinking..."
2. **Validate it** — "That's completely understandable..."
3. **Reframe it** — "But here's what most people miss..."
4. **Resolve it** — Specific answer or proof

### Common Objections to Address

**Time:** "I don't have time"
- Reframe: This saves time, doesn't cost time
- Proof: Specific time investment required

**Skepticism:** "I've tried things before"
- Acknowledge: "You're right to be skeptical"
- Differentiate: Why this is different
- Proof: Specific results

**Self-doubt:** "I'm not [smart/talented/ready] enough"
- Normalize: "Most people feel this way"
- Simplify: Break down what's actually required
- Proof: Success stories from similar people

---

## Section 7: Identity Transformation

### Before Identity
- Struggling beginner
- Overwhelmed and stuck
- Watching others succeed

### After Identity
- Competent operator
- Confident decision-maker
- Someone who gets results

### Status Markers
- "You'll be the person who..."
- "Others will ask you how you..."
- "You'll finally feel like..."

---

## Section 8: Future Visualization

### Scene Structure
1. **Setting** — Where are they?
2. **Action** — What are they doing?
3. **Emotion** — How do they feel?
4. **Result** — What just happened?

### Example Scenes
- Morning routine with new results
- Conversation with friend/family about success
- Checking metrics and seeing growth
- Feeling confident in a previously stressful situation

---

## Section 9: Differentiation

### What This Is NOT
List 3-5 things people might confuse this with:
- "This isn't another [common solution]"
- "This isn't [alternative that doesn't work]"

### Why Others Fail
- Surface-level approaches
- Missing critical components
- One-size-fits-all solutions

### Your Unique Advantage
- Specific methodology
- Proprietary framework
- Unique combination of elements

---

## Section 10: Offer Stack

### Core Components
List everything included:
- Main product/training
- Templates or tools
- Resources or bonuses
- Support or community access

### Value Stacking
Assign dollar values to each component:
- Main product: $X
- Bonus 1: $Y
- Bonus 2: $Z
- **Total value: $XXX**
- **Today's price: $XX**

---

## Section 11: Urgency/Scarcity

### Types of Urgency
1. **Price increase** — "Goes up to $X on [date]"
2. **Bonus expiration** — "This bonus disappears in 48 hours"
3. **Limited spots** — "Only X spots available"
4. **Founder pricing** — "Early adopter rate"

### Legitimate Reasons
- Launch window closing
- Bonus capacity limits
- Price testing phase ending
- Seasonal relevance

---

## Section 12: Guarantee

### Risk Reversal
- Full refund policy
- Specific timeframe (7, 14, 30, 60 days)
- No questions asked (or simple process)

### Confidence Statement
- "I can offer this because I know it works"
- "The only risk is not trying it"

---

## Section 13: CTA Stack

### Primary CTA
- Clear button text or link
- Price reminder
- Urgency reminder

### What Happens Next
- Immediate access instructions
- First steps after purchase
- Support contact info

### Final Hook
- Return to the big promise
- Identity reinforcement
- One last nudge

---

## Quality Checklist

Before finalizing, verify:
- [ ] 2,500+ words
- [ ] 10+ objections addressed
- [ ] 2+ future visualization scenes
- [ ] Specific numbers throughout
- [ ] No vague claims without proof
- [ ] Clear differentiation
- [ ] Strong urgency mechanism
- [ ] Risk-free guarantee stated
- [ ] Tone is confident but not hypey
