---
name: salespage
description: Generate long-form, direct-response sales pages optimized for conversions. Use when the user needs sales copy for digital products, courses, software, or services. Triggers on phrases like "create a sales page", "write sales copy", "build a landing page", "sales letter", or when the user describes a product they want to sell.
metadata:
  openclaw:
    emoji: 🎯
---

# Sales Page Generator

Generate conversion-optimized, long-form sales pages using proven direct-response principles.

## When to Use

✅ **Use this skill when:**
- User asks for a sales page, sales letter, or landing page
- User describes a product/service they want to sell
- User mentions "conversion", "sales copy", or "launch"
- User provides product details and asks for marketing copy

❌ **Don't use when:**
- User wants short-form copy (ads, emails, social posts)
- User needs technical documentation
- User wants a homepage or informational page (not sales-focused)

## Required Input

Before generating, collect:
1. **Product name** — What is being sold?
2. **Price point** — What's the offer price?
3. **Core benefit/mechanism** — What does it do? How does it work?
4. **Target audience** — Who is this for?
5. **Format** (optional) — Plain text, Markdown, or HTML?

If any required info is missing, ask the user before proceeding.

## Output Format

Generate a complete long-form sales page (2,500+ words) with these sections:

### 1. Headline Stack
- Primary headline (big promise)
- Subheadline (mechanism or proof element)
- Pre-headline (qualifier or curiosity hook)

### 2. Opening Hook
- Pattern interrupt
- Problem agitation
- Solution introduction

### 3. External Proof Layer
- Quantified results (even small numbers)
- Timeline to first result
- Revenue/success validation
- At least one testimonial or early adopter story

### 4. Specific Outcome Anchoring
- Tangible results (not vague benefits)
- Time-bound outcomes
- Concrete deliverables

### 5. The Mechanism
- How it works (step-by-step)
- Why it's different
- What makes it effective

### 6. Objection Domination
Address at least 10 objections:
- "I don't have time"
- "I've bought courses before"
- "I don't finish things"
- "I'm not technical"
- "This seems overhyped"
- "I don't have an audience"
- "What if it doesn't work for me?"
- "I can't afford it"
- "I need to think about it"
- "Is this right for my situation?"

### 7. Identity Transformation
- Who the buyer becomes
- Status upgrade
- New capabilities

### 8. Future Visualization
- 2+ vivid scenes of success
- Emotional payoff moments
- Lifestyle improvements

### 9. Differentiation
- What this is NOT
- Why other solutions fail
- Unique advantage

### 10. Offer Stack
- What's included (bullet list)
- Bonuses (if any)
- Total value calculation

### 11. Urgency/Scarcity
- Why buy now
- Price increase timeline
- Bonus expiration
- Limited availability

### 12. Guarantee
- Risk reversal
- Refund terms
- Confidence statement

### 13. CTA Stack
- Primary call-to-action
- What happens after purchase
- Final urgency reminder

## Tone Guidelines

**Voice characteristics:**
- Confident but not arrogant
- Direct but not aggressive
- Authoritative but approachable
- Conversational, not corporate

**Avoid:**
- Hype-heavy bro-marketing
- All-caps screaming
- Excessive exclamation points
- Vague claims without proof

## Examples

See `references/examples.md` for complete sample sales pages.

## Quick Reference

**Word count target:** 2,500+ words minimum  
**Sections:** 13 (as listed above)  
**Objections:** Minimum 10 addressed  
**Future scenes:** Minimum 2 vivid visualizations  

---

*For detailed framework guidance, see `references/framework.md`*  
*For tone and style examples, see `references/examples.md`*
